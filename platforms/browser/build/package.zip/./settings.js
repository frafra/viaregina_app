var SETTINGS = {db_points_url:'http://viaregina3.como.polimi.it/db_points_url', db_users_url:'http://viaregina3.como.polimi.it/db_users_url'};
